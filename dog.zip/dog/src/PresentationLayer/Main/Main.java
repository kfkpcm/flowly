package PresentationLayer.Main;
import PresentationLayer.Forms.Home;

public class Main {
    public static void main(String[] args) {
        Home map = new Home();
    }
}